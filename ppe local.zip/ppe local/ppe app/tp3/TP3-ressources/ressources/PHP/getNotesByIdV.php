<?php
include "fonctions.php";

$idV=$_POST['idV'];
try {
    $cnx = connexionPDO();
    $req = $cnx->prepare("select * from noter where idV=$idV");
    $req->execute();
  
    while ($ligne = $req->fetch(PDO::FETCH_ASSOC)){
        $resultat[]=$ligne;
    }
    print(json_encode($resultat));

} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage();
    die();
}

?>

