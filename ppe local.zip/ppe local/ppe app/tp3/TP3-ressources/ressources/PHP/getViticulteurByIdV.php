<?php
include "fonctions.php";
    
$idV=$_POST['idV'];
try {
    $cnx = connexionPDO();
    $req = $cnx->prepare("select * from viticulteur where idV = $idV");
    $req->execute();
  
    $resultat = $req->fetch(PDO::FETCH_ASSOC);
    print(json_encode($resultat));

} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage();
    die();
}

?>

