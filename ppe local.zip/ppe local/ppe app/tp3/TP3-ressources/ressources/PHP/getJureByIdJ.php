<?php
include "fonctions.php";

$idJ=$_POST['idJ'];
try {
    $cnx = connexionPDO();
    $req = $cnx->prepare("select * from jure where idJ = $idJ");
    $req->execute();
  
    $resultat = $req->fetch(PDO::FETCH_ASSOC);
    print(json_encode($resultat));

} catch (PDOException $e) {
    print "Erreur !: " . $e->getMessage();
    die();
}

?>

