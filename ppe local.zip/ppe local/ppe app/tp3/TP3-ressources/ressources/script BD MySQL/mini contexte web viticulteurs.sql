create table jure (
	idJ integer auto_increment,
	nomJ varchar(50),
	prenomJ varchar(50),
	primary key (idJ)
)ENGINE=InnoDB;

create table viticulteur (
	idV integer auto_increment,
	nomV varchar(50),
	primary key (idV)
)ENGINE=InnoDB;

create table noter (
	idJ integer,
	idV integer,
	note integer,
	primary key (idJ,idV),
	foreign key(idJ) references jure(idJ),
	foreign key(idV) references viticulteur(idV)
)ENGINE=InnoDB;

INSERT INTO `jure` (`idJ`, `nomJ`, `prenomJ`) VALUES
(1, 'Soueix', 'Jean jerome'),
(2, 'Harispe', 'Michel');

INSERT INTO `viticulteur` (`idV`, `nomV`) VALUES
(1, 'Garay'),
(2, 'Esquerra');

INSERT INTO `noter` (`idJ`, `idV`, `note`) VALUES
(1, 1, 50),
(1, 2, 51),
(2, 1, 60);