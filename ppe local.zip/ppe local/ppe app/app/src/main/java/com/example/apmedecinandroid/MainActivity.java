package com.example.apmedecinandroid;

import androidx.appcompat.app.AppCompatActivity;

import org.mindrot.jbcrypt.BCrypt;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.apmedecinandroid.modeles.Hashage;
import com.example.apmedecinandroid.modeles.Users;
import com.example.apmedecinandroid.modeles.UsersDAO;

public class MainActivity extends AppCompatActivity {

    private EditText editTextLogin;
    private EditText editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextLogin = findViewById(R.id.loginEditText);
        editTextPassword = findViewById(R.id.passwordEditText);

        Button btn=(Button)findViewById(R.id.button_connexion);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // avant tout, il faudra vérifier le login et le mot de passe
                // si c'est bon, on peut continuer : on envoie le idMedecin de l'utilisateur à la vue PanelActivity

                String login = editTextLogin.getText().toString();
                String password = editTextPassword.getText().toString();

                //UsersDAO usersDAO = new UsersDAO();
                //Users user = usersDAO.getUserByLogin(login, new UsersDAO.UserCallback());

                UsersDAO usersDAO = new UsersDAO();
                usersDAO.getUserByLogin(login, new UsersDAO.UserCallback() {
                    @Override
                    public void onUserReceived(Users user) {
                        if (user != null) {
                            Log.d("MainActivity", "Utilisateur obtenue: " + user.toString());

                            if (BCrypt.checkpw(password, user.getMotDePasse())) {
                                Log.d("MainActivity", "Mot de passe correct, accès à PanelActivity");

                                Intent intent = new Intent(MainActivity.this, PanelActivity.class);
                                intent.putExtra("send", "Joran");
                                intent.putExtra("idMedecin", user.getId());
                                startActivity(intent);
                            } else {
                                Log.d("MainActivity", "Mot de passe incorrect.");
                            }
                        } else {
                            Log.d("MainActivity", "Aucun utilisateur trouvé avec le login donné.");
                        }
                    }
                });

                /*if (user != null) {
                    // User found in database
                    Log.d("MainActivity", "User fetched: " + user.toString());

                    // Hash the entered password
                    String hashedPassword = null;
                    try {
                        hashedPassword = Hashage.hasher(password);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if (hashedPassword != null && hashedPassword.equals(user.getMotDePasse())) {
                        // The entered password matches the one in the database
                        Log.d("MainActivity", "Password match. Proceeding to PanelActivity.");

                        // Open PanelActivity
                        Intent intent = new Intent(MainActivity.this, PanelActivity.class);
                        intent.putExtra("send", "Joran");
                        startActivity(intent);
                    } else {
                        // The entered password does not match the one in the database
                        Log.d("MainActivity", "Password mismatch.");
                    }
                } else {
                    // No user found with the given login
                    Log.d("MainActivity", "No user found with the given login.");
                }*/


                // Puis ouvrir la vue PanelActivity
                //Intent intent = new Intent(MainActivity.this, PanelActivity.class);
                //intent.putExtra("send", "Joran");
                //startActivity(intent);
            }
        });

    }
}