package com.example.apmedecinandroid.modeles;

public class Rdv {
    private long idRdv;
    private String dateHeureRdv;

    private String nom;
    private String prenom;

    private long idPatient;
    private long idMedecin;
    private String compteRendu;

    public Rdv(long idRdv, String dateHeureRdv, long idPatient, long idMedecin, String compteRendu) {
        this.idRdv = idRdv;
        this.dateHeureRdv = dateHeureRdv;
        this.idPatient = idPatient;
        this.idMedecin = idMedecin;
        this.compteRendu = compteRendu;
    }

    public Rdv(long idRdv, String nom, String prenom, String dateHeureRdv) {
        this.idRdv = idRdv;
        this.nom = nom;
        this.prenom = prenom;
        this.dateHeureRdv = dateHeureRdv;
    }

//    public Rdv(String nomJ,String prenomJ) {
//        this.idRdv = -1;
//        this.nomJ = nomJ;
//        this.prenomJ = prenomJ;
//    }

    public long getidRdv() {
        return idRdv;
    }

    public void setidRdv(long idRdv) {
        this.idRdv = idRdv;
    }

    public String getdateHeureRdv() {
        return dateHeureRdv;
    }

    public void setdateHeureRdv(String dateHeureRdv) {
        this.dateHeureRdv = dateHeureRdv;
    }

    public long getidPatient() {
        return idPatient;
    }

    public void setidPatient(Long idPatient) {
        this.idPatient = idPatient;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
    public long getidMedecin() {
        return idMedecin;
    }

    public void setidMedecin(Long idMedecin) {
        this.idMedecin = idMedecin;
    }

    public String getcompteRendu() {
        return compteRendu;
    }

    public void setcompteRendu(String compteRendu) {
        this.compteRendu = compteRendu;
    }

    public String toString(){
//        return "idRdv="+idRdv+",dateHeureRdv="+dateHeureRdv+",idPatient="+idPatient+",idMedecin="+idMedecin+",compteRendu="+compteRendu;

        return "nom="+nom+"prenom="+prenom+"dateHeureRdv="+dateHeureRdv;
    }
}
