package com.example.apmedecinandroid;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.apmedecinandroid.modeles.Rdv;
import com.example.apmedecinandroid.modeles.RdvDAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PanelActivity extends AppCompatActivity {

    private DatePicker datePicker;
    private ScrollView scrollViewPatients;
    private LinearLayout linearLayoutPatients;
    private Button buttonAfficherValider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panel);

        datePicker = findViewById(R.id.datePicker);
        scrollViewPatients = findViewById(R.id.scollViewPatients);
        linearLayoutPatients = findViewById(R.id.linearLayoutPatients);
        buttonAfficherValider = findViewById(R.id.buttonAfficherValider);

        //Clotilde GUIBE
        //String idMedecin = "16e3cbd02663ea1d89c06efeca5bbdb1d683f490";

        //String idMedecin = "d0084bea9049e11e0cb060dcef340c97d8f3e113";

        String idMedecin = getIntent().getStringExtra("idMedecin");

        // Charger une liste de patients
        // Charger une liste de rendez-vous
        //sélectionner une date et charger les rendez-vous de cette date

        buttonAfficherValider.setOnClickListener(v -> {

            Toast.makeText(PanelActivity.this, "Bouton cliqué !", Toast.LENGTH_SHORT).show();

            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1;
            int year = datePicker.getYear();
            String selectedDate = String.format("%04d-%02d-%02d", year, month, day);

            RdvDAO rdvDAO = new RdvDAO() {
                @Override
                public void onTacheTerminee(String value) {

                }

                @Override
                public void onTacheTerminee(ArrayList<Rdv> listeRdv) {

                    linearLayoutPatients.removeAllViews();

                    Log.d("PanelActivity", "onTacheTerminee called");

                    Log.d("PanelActivity", "ListeRdv : " + listeRdv);

                    for (Rdv rdv : listeRdv) {
                        Log.d("PanelActivity", "Rdv: " + rdv.toString());
                        TextView textView = new TextView(PanelActivity.this);

                        try {
                            String dateHeureRdv = rdv.getdateHeureRdv();
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            Date d = sdf.parse(dateHeureRdv);
                            sdf.applyPattern("HH:mm");
                            String heureRdv = sdf.format(d);

                            textView.setText(String.format("Nom %s - Prenom %s - Heure %s",
                                    rdv.getNom(), rdv.getPrenom(), heureRdv));

                            Button button = new Button(PanelActivity.this);
                            button.setText("Valider");
                            button.setOnClickListener(new View.OnClickListener() {
                                public void onClick(View v) {
                                    Intent intent = new Intent(PanelActivity.this, DetailActivity.class);
                                    intent.putExtra("idRdv", String.valueOf(rdv.getidRdv()));
                                    startActivity(intent);
                                }
                            });

                            Log.d("PanelActivity", "Adding TextView to LinearLayout");
                            linearLayoutPatients.addView(textView);
                            linearLayoutPatients.addView(button);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

//                        textView.setText(String.format("Rdv %d - Patient %d - Medecin %d - %s",
//                                rdv.getidRdv(), rdv.getidPatient(), rdv.getidMedecin(), rdv.getdateHeureRdv()));
                        //textView.setText(String.format("Rdv %d - Patient %d - Medecin %d - %"));
                        //textView.setText(String.format("Rdv %d - Patient %d - Medecin %d - %s",
                                //rdv.getidRdv(), rdv.getidPatient(), rdv.getidMedecin(), rdv.getdateHeureRdv()));
                        //textView.setText(String.format("Nom %s - Prenom %s - Heure %s",
                                //rdv.getNom(), rdv.getPrenom(), rdv.getdateHeureRdv()));

                    }
                }

                @Override
                public void onTacheTerminee(Rdv resultat) {

                }
            };
//            rdvDAO.getRdvByDate(selectedDate);
            rdvDAO.getRdvById(idMedecin, selectedDate);
        });
    }
}