package com.example.apmedecinandroid.modeles;

public class Users {

    private String id;
    private String login;
    private String motDePasse;

    public Users(String unId, String unLogin, String unMotDePasse)
    {
        this.id = unId;
        this.login = unLogin;
        this.motDePasse = unMotDePasse;
    }

    public String getId()
    {
        return this.id;
    }

    public void setId(String unId)
    {
        this.id = unId;
    }

    public String getLogin()
    {
        return this.login;
    }

    public void setLogin(String unLogin)
    {
        this.login = unLogin;
    }

    public String getMotDePasse()
    {
        return this.motDePasse;
    }

    public void setMotDePasse(String unMotDePasse)
    {
        this.motDePasse = unMotDePasse;
    }

    public String toString()
    {
        return "Id : " + this.id + " Login : " + this.login + " Mot de passe : " + this.motDePasse;
    }
}
