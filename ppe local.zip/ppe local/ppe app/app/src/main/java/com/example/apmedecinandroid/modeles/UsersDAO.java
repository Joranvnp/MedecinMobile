    package com.example.apmedecinandroid.modeles;

    import android.util.Log;

    import com.example.apmedecinandroid.utilitaire.AccesHTTP;

    import org.json.JSONException;
    import org.json.JSONObject;

    public class UsersDAO {
        private static final String serveur = "10.0.2.2/";
        private static final String chemin = "MVC/";

        public interface UserCallback {
            void onUserReceived(Users user);
        }

        public void getUserByLogin(final String login, final UserCallback callback) {
            AccesHTTP requeteHttp = new AccesHTTP("GET") {
                @Override
                protected void onPostExecute(Long result) {
                    Users user = jsonStringToUser(this.ret);
                    if (user != null) {
                        Log.d("UsersDAO", "User fetched: " + user.toString());
                        callback.onUserReceived(user);
                    } else {
                        Log.d("UsersDAO", "Failed to fetch user");
                    }
                }
            };
            requeteHttp.execute("http://" + serveur + chemin + "index.php?action=medecin&login=" + login);
        }


        private Users jsonStringToUser(String jsonString) {
            try {
                JSONObject objJson = new JSONObject(jsonString);
                String id = objJson.getString("idMedecin");
                String login = objJson.getString("loginMedecin");
                String motDePasse = objJson.getString("mdpMedecin");
                return new Users(id, login, motDePasse);
            } catch (JSONException e) {
                Log.d("UsersDAO", "JSON decoding error: " + e.getMessage());
                e.printStackTrace();
                return null;
            } catch (NumberFormatException e) {
                Log.d("UsersDAO", "Error parsing id to integer: " + e.getMessage());
                e.printStackTrace();
                return null;
            }
        }

    }
