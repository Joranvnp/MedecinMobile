package com.example.apmedecinandroid;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.apmedecinandroid.modeles.Rdv;
import com.example.apmedecinandroid.modeles.RdvDAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DetailActivity extends AppCompatActivity {

    private EditText editTextCompteRendu;

    private Button buttonValider;

    private Button buttonAnnuler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        editTextCompteRendu = findViewById(R.id.editTextCompteRendu);
        buttonValider = findViewById(R.id.buttonValider);
        buttonAnnuler = findViewById(R.id.buttonAnnuler);

        Intent intent = getIntent();
        String idRdv = intent.getStringExtra("idRdv");

        buttonValider.setOnClickListener(v -> {
            Toast.makeText(DetailActivity.this, "Bouton cliqué !", Toast.LENGTH_SHORT).show();

            String compteRendu = editTextCompteRendu.getText().toString();

            if(!compteRendu.isEmpty()) {
                RdvDAO rdvDAO = new RdvDAO() {
                    @Override
                    public void onTacheTerminee(String value) {
                        Toast.makeText(DetailActivity.this, value, Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onTacheTerminee(ArrayList<Rdv> listeRdv) {

                    }

                    @Override
                    public void onTacheTerminee(Rdv resultat) {

                    }
                };

                Log.d("Log", "idRdv: " + idRdv);
                Log.d("Log", "compteRendu: " + compteRendu);

                rdvDAO.patchRdv(idRdv, compteRendu);
            } else {
                Toast.makeText(DetailActivity.this, "Le compte rendu ne doit pas être vide.", Toast.LENGTH_LONG).show();
            }
        });

        Log.d("Log", "IdRdv"+getIntent().getStringExtra("idRdv"));
    }
}